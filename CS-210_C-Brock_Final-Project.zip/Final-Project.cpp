#include <iostream>
#include <fstream>
#include <map>
#include <string>
#include <iomanip>

using namespace std;

class ItemTracker {
private:
    map<string, int> itemFrequency;
    string inputFile = "Final-Project-Input.txt";
    string backupFile = "frequency.dat";

    void loadItems() {
        ifstream inFile(inputFile);
        if (!inFile) {
            cerr << "Error opening input file!" << endl;
            cerr << "Exiting function due to error." << endl; return;
        }
        string item;
        while (inFile >> item) {
            itemFrequency[item]++;
        }
        inFile.close();
        backupData();
    }

    void backupData() {
        ofstream outFile(backupFile);
        if (!outFile) {
            cerr << "Error creating backup file!" << endl;
            cerr << "Exiting function due to error." << endl; return;
        }
        for (const auto& pair : itemFrequency) {
            outFile << pair.first << " " << pair.second << endl;
        }
        outFile.close();
    }

public:
    ItemTracker() {
        loadItems();
    }

    int getItemFrequency(const string& item) {
        return itemFrequency.count(item) ? itemFrequency[item] : 0;
    }

    void printFrequencies() {
        cout << "\nItem Frequencies:\n";
        for (const auto& pair : itemFrequency) {
            cout << pair.first << " " << pair.second << endl;
        }
    }

    void printHistogram() {
        cout << "\nItem Frequency Histogram:\n";
        for (const auto& pair : itemFrequency) {
            cout << setw(15) << left << pair.first << " ";
            for (int i = 0; i < pair.second; ++i) {
                cout << "*";
            }
            cout << endl;
        }
    }
};

void displayMenu() {
    cout << "\nCorner Grocer Item Tracker\n";
    cout << "1. Look up an item frequency\n";
    cout << "2. Print all item frequencies\n";
    cout << "3. Print histogram\n";
    cout << "4. Exit\n";
    cout << "Enter your choice: ";
}

int main() {
    ItemTracker tracker;
    int choice;
    do {
        displayMenu();
        cin >> choice;
        switch (choice) {
            case 1: {
                string item;
                cout << "Enter item name: ";
                cin >> item;
                cout << "Frequency: " << tracker.getItemFrequency(item) << endl;
                break;
            }
            case 2:
                tracker.printFrequencies();
                break;
            case 3:
                tracker.printHistogram();
                break;
            case 4:
                cout << "Exiting program." << endl;
                break;
            default:
                cout << "Invalid choice, please try again." << endl;
        }
    } while (choice != 4);
    return 0;
}
